import { ref } from "vue";
import axios from "axios";
import { useRouter } from "vue-router";

export default function useCategories() {
    const categories = ref([]);
    const category = ref([]);
    const slides = ref([]);
    const router = useRouter();
    const errors = ref("");
    const products = ref([]);
    const accessories = ref([]);

    const getCategories = async () => {
        let response = await axios.get("/api/categories");
        categories.value = response.data.data;
    };
    const getFlagsOrSigns = async (type) => {
        let response = await axios.get("/api/get-flags-signs?type=" + type);
        categories.value = response.data.data;
    };
    const getSlides = async () => {
        let response = await axios.get("/api/categories-slides");
        slides.value = response.data.data;
    };

    const getCategory = async (id) => {
        let response = await axios.get("/api/categories/" + id);
        category.value = response.data.data;
    };
    const getCategoryDetails = async (slug) => {
        let response = await axios.get("/api/category/" + slug);
        console.log(response.data);
        category.value = response.data.category;
        products.value = response.data.products;
        accessories.value = response.data.accessories;
        console.log(accessories.value);
    };

    const storeCategory = async (data) => {
        let fd = new FormData();
        fd.append("category", data.form.category);
        fd.append("name_en", data.form.name_en);
        fd.append("name_ar", data.form.name_ar);
        fd.append("description_en", data.form.description_en);
        fd.append("description_ar", data.form.description_ar);
        fd.append("is_slide", data.form.is_slide);
        fd.append("is_trending", data.form.is_trending);
        fd.append("category_img", data.form.image);
        fd.append("image", data.file);
        fd.append("properties", JSON.stringify(data.properties));
        errors.value = "";
        try {
            await axios.post("/api/categories", fd, {
                onUploadProgress: function (progressEvent) {
                    // uploadPercentage = parseInt(
                    //     Math.round(
                    //         (progressEvent.loaded / progressEvent.total) * 100
                    //     )
                    // );
                    console.log(
                        Math.round(
                            (progressEvent.loaded / progressEvent.total) * 100
                        )
                    );
                },
            });
            await router.push({ name: "categories.index" });
        } catch (e) {
            if (e.response.status === 422) {
                errors.value = e.response.data.errors;
            }
        }
    };

    const updateCategory = async (id, data) => {
        console.log(data);
        let fd = new FormData();
        fd.append("_method", "patch");
        fd.append("category", data.form.category);
        fd.append("name_en", data.form.name_en);
        fd.append("name_ar", data.form.name_ar);
        fd.append("description_en", data.form.description_en);
        fd.append("description_ar", data.form.description_ar);
        fd.append("is_slide", data.form.is_slide);
        fd.append("is_trending", data.form.is_trending);
        fd.append("category_img", data.form.image);
        fd.append("new_image", data.file);
        fd.append("properties", JSON.stringify(data.form.properties));

        errors.value = "";
        try {
            await axios.post("/api/categories/" + id, fd, {
                headers: {
                    "Content-Type": "multipart/form-data",
                },
            });
            await router.push({ name: "categories.index" });
        } catch (e) {
            if (e.response.status === 422) {
                errors.value = e.response.data.errors;
            }
        }
    };

    const deleteProperty = async (id) => {
        await axios.delete("/api/cat-property/" + id);
    };
    const destroyCategory = async (id) => {
        await axios.delete("/api/categories/" + id);
    };

    return {
        categories,
        category,
        errors,
        getCategories,
        getCategory,
        storeCategory,
        updateCategory,
        destroyCategory,
        deleteProperty,
        getSlides,
        slides,
        getCategoryDetails,
        products,
        accessories,
        getFlagsOrSigns,
    };
}
