<template>
  <div class="preloader">
    <div class="flex items-center justify-center space-x-2 animate-bounce">
      <div class="w-8 h-8 bg-red-700 rounded-full"></div>
      <div class="w-8 h-8 bg-white rounded-full"></div>
      <div class="w-8 h-8 bg-black rounded-full"></div>
    </div>
  </div>
</template>
  
  <style>
.preloader {
  padding-top: 30vh;
}
</style>