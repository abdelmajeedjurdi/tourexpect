<template>
  <!-- component -->
  <div v-if="isLoading">
    <preloader />
  </div>
  <div v-else>
    <hero-carousel :slides="slides" />
    <div class="flex justify-center items-center">
      <!--- more free and premium Tailwind CSS components at https://tailwinduikit.com/ --->
      <div
        class="2xl:mx-auto 2xl:container lg:px-20 md:px-6 px-4 w-96 sm:w-auto"
      >
        <div class="lg:flex items-stretch md:mt-12 my-8">
          <div class="grid grid-cols-1 sm:grid-cols-2 items-center">
            <div
              class="relative h-full brightness"
              v-for="category in categories"
              :key="category.id"
            >
              <router-link
                :to="{
                  name: 'category',
                  params: { slug: category['slug'] },
                }"
              >
                <div>
                  <div
                    class="absolute bottom-0 p-6"
                    :class="lang == 'en' ? 'left-0' : 'right-0'"
                  >
                    <h2 class="text-base lg:text-xl font-semibold 5 text-white">
                      {{ category["name_" + lang] }}
                    </h2>
                    <p class="text-sm lg:text-base leading-4 text-white mt-2">
                      {{
                        category["description_" + lang].substring(0, 100) +
                        (category["description_" + lang].length > 100
                          ? "...."
                          : "")
                      }}
                    </p>
                  </div>
                </div>
                <img
                  :src="'/images/categories/' + category.image"
                  class="w-full h-full"
                  alt="chair"
                />
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { onMounted, ref } from "@vue/runtime-core";
import useCategories from "../../../composables/categories";
import HeroCarousel from "../../../components/HeroCarousel";
import Preloader from "../../frontend/Preloader.vue";
import { inject } from "vue";
let isLoading = ref(false);
let { categories, getCategories, slides, getSlides } = useCategories();
let lang = ref(inject("lang") || "en");
onMounted(async () => {
  isLoading.value = true;
  await getCategories();
  await getSlides();
  isLoading.value = false;
});
</script>
<style>
.brightness:hover {
  filter: brightness(1.5);
  transition-duration: 1s;
}
</style>