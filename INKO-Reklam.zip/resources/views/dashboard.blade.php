<x-app-layout>
    @include('layouts.navigation')
    <backend-view />
</x-app-layout>
