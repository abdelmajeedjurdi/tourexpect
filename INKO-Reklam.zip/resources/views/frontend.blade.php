<x-app-layout>
    <frontend-view />
</x-app-layout>
