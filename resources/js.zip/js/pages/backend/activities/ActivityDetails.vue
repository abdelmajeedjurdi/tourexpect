<template>
    <h1 class="text-purple-800 font-bold">This page will be added soon</h1>
</template>
