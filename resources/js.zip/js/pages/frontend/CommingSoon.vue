<template>
  <div class="h-screen bg-white pt-40">
    <h1 class="text-6xl text-red-500 mx-auto w-full text-center font-bold">
      Coming Soon
    </h1>
  </div>
</template>
