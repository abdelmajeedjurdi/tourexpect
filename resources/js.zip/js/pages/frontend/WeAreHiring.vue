<template>
    <div class="sm:px-4 xl:px-0 sm:flex w-full max-w-6xl mx-auto my-28">
        <div class="">
            <p>
                Human resources are the core of our interest at Tourexpect as we
                always focus on developing our staff and improve our team.
            </p>
            <p>
                We are always looking for promising talents who want to prove
                their worth. Besides, we are working to develop their
                capabilities so that they meet our goals and objectives, and we
                seek to provide our team with expertise and professional skills
                adding to our work what is new and fruitful.
            </p>
            <h3 class="mt-4 text-lg font-semibold">Join Tourexpect Team</h3>
            <p>
                If you are one of those who have experience in our field of
                work, and at the beginning of youth, and enjoy high ambition,
                spirit of fair competition and challenge to reach the
                professional goals that we aspire to, you can be part of
                Tourexpect team, by sending your CV. We will contact you in case
                there are suitable and available vacancies, or we will keep your
                job files for the appropriate time.
            </p>
            <h3 class="mt-4 text-lg font-semibold">
                Our Vision For Work And Employment:
            </h3>
            <p>
                We believe in working as a united team, respecting employees'
                rights, and applying humanitarian and ethical standards in
                treatment.
            </p>
            <p>
                The successful employee must be of courtesy, ethics, and high
                values to provide the best service to our valued clients.
                Successful employees are the key to corporate success, so we are
                interested in attracting outstanding talents and experienced
                competencies.
            </p>
            <p>
                We always aim to work with the finest people to preserve our
                reputation, improve our distinguished services, and uphold our
                social responsibility by providing a comfortable and effective
                work environment.
            </p>
            <div>
                <form>
                    <div class="rounded-lg border-2 border-gray-300">
                        <div
                            class="rounded-lg bg-blue-900 py-3 text-center text-xl font-semibold text-white"
                        >
                            Apply To Join Tourexpect Team
                        </div>
                        <div class="grid grid-cols-2 gap-2 p-6">
                            <input
                                type="text"
                                class="rounded-lg border py-1 px-2 focus:border-blue-900"
                                placeholder="Your Name"
                            />
                            <input
                                type="text"
                                class="rounded-lg border py-1 px-2 focus:border-blue-900"
                                placeholder="Position"
                            />
                            <input
                                type="email"
                                class="rounded-lg border py-1 px-2 focus:border-blue-900"
                                placeholder="Your Email"
                            />
                            <input
                                type="url"
                                class="rounded-lg border py-1 px-2 focus:border-blue-900"
                                placeholder="LinkedIn link "
                            />
                            <input
                                type="text"
                                class="rounded-lg border py-1 px-2 focus:border-blue-900"
                                placeholder="Your Phone"
                            />
                            <div>
                                <input
                                    class="rounded-lg border py-1 px-2 focus:border-blue-900"
                                    type="file"
                                />
                            </div>
                            <textarea
                                name=""
                                id=""
                                cols="30"
                                rows="6"
                                class="rounded-lg border py-1 px-2"
                                placeholder="Your Message"
                            ></textarea>
                            <div class="flex items-end justify-end">
                                <button
                                    class="rounded-2xl bg-orange-500 px-12 py-1 text-white"
                                >
                                    Apply
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div>
                <div
                    class="mt-8 flex justify-between rounded-lg bg-blue-500 px-8 py-2"
                >
                    <div>
                        <h3 class="text-lg text-white">
                            Visa Application Form
                        </h3>
                        <div class="mt-1 text-sm text-sky-200">
                            Erbil-Full time
                        </div>
                    </div>
                    <div class="flex items-center">
                        <button
                            class="rounded-full bg-white px-12 py-1 text-blue-500"
                        >
                            Apply
                        </button>
                    </div>
                </div>
                <div
                    class="mt-4 flex justify-between rounded-lg bg-blue-500 px-8 py-2"
                >
                    <div>
                        <h3 class="text-lg text-white">
                            Visa Application Form
                        </h3>
                        <div class="text-sm text-sky-200">Erbil-Full time</div>
                    </div>
                    <div class="flex items-center">
                        <button
                            class="rounded-full bg-white px-12 py-1 text-blue-500"
                        >
                            Apply
                        </button>
                    </div>
                </div>
                <div
                    class="mt-4 flex justify-between rounded-lg bg-blue-500 px-8 py-2"
                >
                    <div>
                        <h3 class="text-lg text-white">
                            Visa Application Form
                        </h3>
                        <div class="text-sm text-sky-200">Erbil-Full time</div>
                    </div>
                    <div class="flex items-center">
                        <button
                            class="rounded-full bg-white px-12 py-1 text-blue-500"
                        >
                            Apply
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
